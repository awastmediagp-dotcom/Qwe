fetch('assets/news.json')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('news-container');
    data.forEach(item => {
      const card = document.createElement('div');
      card.classList.add('news-card');
      card.innerHTML = `
        <h2>${item.title}</h2>
        <p>${item.date}</p>
        <p>${item.content}</p>
      `;
      container.appendChild(card);
    });
  })
  .catch(err => console.error('Помилка завантаження новин:', err));
`